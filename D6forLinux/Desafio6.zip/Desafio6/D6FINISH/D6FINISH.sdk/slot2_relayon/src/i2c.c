#include <stdio.h>
#include "platform.h"
#include "xgpio_l.h"
void usleep(unsigned long int useconds)
{
 int i,j;
 for (j=0;j<useconds;j++)
   for (i=0;i<15;i++) asm("nop");
}
void epromwr(int adrr, int value)//(addr range 0-8191)(value range 0-255)
{
//0breset1/hold1/demux1/start1/rw1/ga3/regaddr16/i_data8
//XGpio_WriteReg(0x40090000, 0, 0b00100000101010101000000100000000);
	XGpio_WriteReg(0x40090000, 0, 671088640 + adrr*256 + value);
	usleep(30);
	XGpio_WriteReg(0x40090000, 0, 2013265920 + adrr*256 + value);
	usleep(30);
	XGpio_WriteReg(0x40090000, 0, 939524096 + adrr*256 + value);
	usleep(30);
}

int epromrd(int adrr)//(addr range 0-8191)(value range 0-255)
{
	int read_value;
//0breset1/hold1/demux1/start1/rw1/ga3/regaddr16/i_data8
//XGpio_WriteReg(0x40090000, 0, 0b00100000101010101000000100000000);
	XGpio_WriteReg(0x40090000, 0, 536870912 + adrr*256);
	usleep(30);
	XGpio_WriteReg(0x40090000, 0, 1879048192 + adrr*256);
	usleep(30);
	XGpio_WriteReg(0x40090000, 0, 805306368 + adrr*256);
	usleep(30);
	read_value = XGpio_ReadReg(0x40090000, 0) - 256 ; // axi_gpio_6 read
	return(read_value);
}
//(addr range 0-8191)(value range 0-255)
