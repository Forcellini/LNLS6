#!/bin/bash
/opt/Xilinx/SDK/2016.2/bin/xsdb -interactive TCL/slot2_relayon.tcl
