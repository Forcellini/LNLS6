

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "platform.h"
#include "xgpio_l.h"
#include "i2c.h"

void print(char *str);
//reset/updater/i_cnv/i_chainsel/R4/R3/R2/R1

int main()
{
	float k = 5;
	int c = 0;
	int canalA[10] = {0,0,0,0,0,0,0,0,0,0};
	int canalB[10] = {0,0,0,0,0,0,0,0,0,0};
	int canalC[10] = {0,0,0,0,0,0,0,0,0,0};
	int canalD[10] = {0,0,0,0,0,0,0,0,0,0};
	int canalA2[10] = {0,0,0,0,0,0,0,0,0,0};
	int canalB2[10] = {0,0,0,0,0,0,0,0,0,0};
	int canalC2[10] = {0,0,0,0,0,0,0,0,0,0};
	int canalD2[10] = {0,0,0,0,0,0,0,0,0,0};

	float medA = 0;
	float medB = 0;
	float medC = 0;
	float medD = 0;
	float medA2 = 0;
	float medA3 = 0;
	float medA4 = 0;
	float medA5 = 0;
	float medB2 = 0;
	float medB3 = 0;
	float medB4 = 0;
	float medB5 = 0;
	float medC2 = 0;
	float medC3 = 0;
	float medC4 = 0;
	float medC5 = 0;
	float medD2 = 0;
	float medD3 = 0;
	float medD4 = 0;
	float medD5 = 0;

	float varA = 0;
	float varB = 0;
	float varC = 0;
	float varD = 0;
	float varA2 = 0;
	float varB2 = 0;
	float varC2 = 0;
	float varD2 = 0;
	int j = 0;

	//reset/updater/i_cnv/i_chainsel/R4/R3/R2/R1
	XGpio_WriteReg(0x40000000, 0,  0b00000011000000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001000000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);
	XGpio_WriteReg(0x40000000, 0,  0b00000001100000);
	usleep(1000);

while(1){
j=0;
varA = 0;
medA5= medA4;
medA4= medA3;
medA3= medA2;
medA2= medA;
medB5= medB4;
medB4= medB3;
medB3= medB2;
medB2= medB;
medC5= medC4;
medC4= medC3;
medC3= medC2;
medC2= medC;
medD5= medD4;
medD4= medD3;
medD3= medD2;
medD2= medD;
medA =0;
medB = 0;
medC =0;
medD =0;

while(j<1000){

	canalA[j] = XGpio_ReadReg(0x40050000, 0);

	canalB[j] = XGpio_ReadReg(0x40060000, 0);

	canalC[j] = XGpio_ReadReg(0x40070000, 0);

	canalD[j] = XGpio_ReadReg(0x40080000, 0);
	medA = roundf((medA + pow(canalA[j],2)*0.001));
	medB = roundf((medB + pow(canalB[j],2)*0.001));
	medC = roundf((medC + pow(canalC[j],2)*0.001));
	medD = roundf((medD + pow(canalD[j],2)*0.001));
	j++;
}


medA = pow(medA,0.5);
medB = pow(medB,0.5);
medC = pow(medC,0.5);
medD = pow(medD,0.5);
varA =0;varB =0;varC =0;varD =0;varA2 =0;varB2 =0;varC2 = 0;varD2 = 0;

varA = pow((pow(medA2 - medA,2)+pow(medA3 - medA,2)+pow(medA4 - medA,2)+pow(medA5 - medA,2))/5,0.5);
varB = pow((pow(medB2 - medB,2)+pow(medB3 - medB,2)+pow(medB4 - medB,2)+pow(medB5 - medB,2))/5,0.5);
varC = pow((pow(medC2 - medC,2)+pow(medC3 - medC,2)+pow(medC4 - medC,2)+pow(medC5 - medC,2))/5,0.5);
varD = pow((pow(medD2 - medD,2)+pow(medD3 - medD,2)+pow(medD4 - medD,2)+pow(medD5 - medD,2))/5,0.5);
printf("\n\n\n\n\nCANAL A = %.0f",medA);
printf("\n\nDPA = %.0f",varA);
printf("\n\nCANAL B = %.0f",medB);
printf("\n\nDPB = %.0f",varB);
printf("\n\nCANAL C = %.0f",medC);
printf("\n\nDPC = %.0f",varC);
printf("\n\nCANAL D = %.0f",medD);
printf("\n\nDPD = %.0f",varD);


}

	return 0;
}
