

#ifndef __I2C_H_
#define __I2C_H_

#include "i2c.h"

void print();
void usleep();
void epromwr();
int epromrd();

#endif
